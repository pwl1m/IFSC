from algoritmos import Classe
from analisa_dados import Analisa

        
if __name__ == "__main__":
    print("_____RELATÓRIO DE VELOCIDADE E EFICIÊNCIA_____")
    print(" ")
    print("Serão analisados:")
    print(" ")
    print("Vetores com 10 posições com valores de 0 a 999")
    print("média de tempo de criação de vetor ordenado  {:.16f} segundos".format(Analisa.criaOrdenado(10)))
    print("média de tempo de mergeSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.mergesort, 10)))
    print("média de tempo de shellSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.shellSort, 10)))
    print("média de tempo de quickSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.quickSort, 10)))
    print("média de tempo de bubbleSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.bubbleSort, 10)))
    print("média de tempo de selectSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.selectSort, 10)))
    print("média de tempo de insertSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.insertSort, 10)))
    print(" ")
    print("Vetores com 100 posições com valores de 0 a 999")
    print("média de tempo de criação de vetor ordenado  {:.16f} segundos".format(Analisa.criaOrdenado(100)))
    print("média de tempo de mergeSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.mergesort, 100)))
    print("média de tempo de shellSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.shellSort, 100)))
    print("média de tempo de quickSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.quickSort, 100)))
    print("média de tempo de bubbleSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.bubbleSort, 100)))
    print("média de tempo de selectSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.selectSort, 100)))
    print("média de tempo de insertSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.insertSort, 100)))
    print(" ")
    print("Vetores com 1000 posições com valores de 0 a 999")
    print("média de tempo de criação de vetor ordenado  {:.16f} segundos".format(Analisa.criaOrdenado(1000)))
    print("média de tempo de mergeSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.mergesort, 1000)))
    print("média de tempo de shellSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.shellSort, 1000)))
    print("média de tempo de quickSort  {:.16f} segundos".format(Analisa.calculaTempo(Classe.quickSort, 1000)))
    print("média de tempo de bubbleSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.bubbleSort, 1000)))
    print("média de tempo de selectSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.selectSort, 1000)))
    print("média de tempo de insertSort {:.16f} segundos".format(Analisa.calculaTempo(Classe.insertSort, 1000)))
    


n = np.linspace(
    1, 10, 100, 50
)  # Gera 100 números entre 1 e 10 e esses números estarão espaçados igualmente, ou seja, linearmente espaçados

print(n)

# Label contendo as funções do Big(O)
labels = ['Constante', 'Logarítmico', 'Linear', 'quadratica','cubica','exponencial']
# np.ones(n.shape) gera 100 números "1".
# shape serve para mostrar o comprimento das dimensões do array
big_o = [np.ones(n.shape), np.log(n), n, n*n, n*n*n, 2**n] 

# Definindo o gráfico
plt.figure(figsize=(5, 4))  # Define o tamanho da figura
plt.ylim(0, 10)  # Define o limite do y
plt.xlim(1, 10)  # Define o limite do y

# Gerando gráficos
for i in range(len(big_o)):
    plt.plot(n, big_o[i], label=labels[i])  #entender essa linha
plt.legend() 
plt.ylabel('Tempo de execução')
plt.xlabel('n')

# Exibindo
plt.show()
